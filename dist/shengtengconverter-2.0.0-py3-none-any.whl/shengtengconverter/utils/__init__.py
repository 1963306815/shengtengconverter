from .view import *
from .delete import *
from .analyse import *

__version__ = "2.0.0"